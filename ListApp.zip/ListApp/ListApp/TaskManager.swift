import UIKit

var taskMgr: TaskManager = TaskManager()

struct task{
    var name="unname"
    var desc="undescripe"
}

class TaskManager: NSObject {
    var tasks = [task]()
    
    func addtask(name1: String, desc1: String){
        tasks.append(task(name: name1, desc: desc1)  );
    }
}
